-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2019 at 04:25 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tdn`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `article` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `article`, `date`) VALUES
(1, 1, 'Hello from Israel !', 'Very pleased to announce that this web app is finaly completed !!', '2019-08-03 15:35:51'),
(2, 2, 'Greetings from the US!', 'Hi everybody! \r\nI am so pleased to be here.\r\nGonna tell you allll about my recent trips...\r\n:)', '2019-08-03 15:50:11'),
(5, 3, 'WOW!', 'What a nice website!\r\nI was waiting for this kind of initiative my hole life!!!!\r\nThank you.', '2019-08-03 15:55:37'),
(6, 4, 'Helloooo!', '\r\nJust left the set in Hollywood to be here with you guys;\r\n\r\nLet me tell you all about my recent travels to Ethiopia...', '2019-08-03 15:59:00'),
(7, 5, 'Hola from Spain!', 'Roberto here, reporting from the scenes.', '2019-08-03 17:05:09');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'Eliran Buskila', 'eliran.bus@gmail.com', '$2y$10$Z553noF0NBV5hN55ahwmfOSXeNxFZHwdqfLFuj.gValV6vfeQsVKy'),
(2, 'Jessica Alba', 'jessica@gmail.com', '$2y$10$KDu46l/SaDCXpR0d7DQ7VuCKiU9MYPujoxT.G8PRV9PevfweEQfhG'),
(3, 'Tal Haim', 'tal@gmail.com', '$2y$10$ujZr6N7fvU/Jnz/BY1nTVu2NvYX/Ed51k1QQ9c1HZK8P77Pz6cvgW'),
(4, 'Johnny Depp', 'johnny@gmail.com', '$2y$10$ZvrT8BuL6rHVjAajhJTwFOFb00ndrFcPWor5BEW420S8N7klbRCUW'),
(5, 'Roberto Cavalli', 'roberto@gmail.com', '$2y$10$AHuXRrAH05fKmW5jOQr9v..3tRscR6ZrNck7GJcxD9wAJDPX0lNca');

-- --------------------------------------------------------

--
-- Table structure for table `users_profile`
--

CREATE TABLE `users_profile` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `avatar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_profile`
--

INSERT INTO `users_profile` (`id`, `user_id`, `avatar`) VALUES
(1, 1, '2019.08.03.14.43.07-2019.07.31.12.00.33-IMG_4385.jpg'),
(2, 2, '2019.08.03.14.53.56-2019.07.24.11.11.46-bricks-brickwork-concrete-269063.jpg'),
(3, 3, '2019.08.03.14.54.35-2019.07.30.16.35.24-lion-588144_1920.jpg'),
(4, 4, '2019.08.03.15.00.17-2019.08.01.09.53.21-IMG_7703.jpg'),
(5, 5, '2019.08.03.16.06.18-IMG_0793.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users_profile`
--
ALTER TABLE `users_profile`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users_profile`
--
ALTER TABLE `users_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
